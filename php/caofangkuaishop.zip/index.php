<?php
function timer_start() {
	global $timestart;

	$timestart = microtime( true );

	return true;
}
timer_start();
function timer_stop( $display = 0, $precision = 3 ) {
	global $timestart, $timeend;

	$timeend   = microtime( true );
	$timetotal = $timeend - $timestart;

	if ( function_exists( 'number_format_i18n' ) ) {
		$r = number_format_i18n( $timetotal, $precision );
	} else {
		$r = number_format( $timetotal, $precision );
	}

	if ( $display ) {
		echo $r;
	}

	return $r;
}
function performance( $visible = false ) {
    $stat = sprintf( '本页生成耗时 %.3f 秒，使用 %.2fMB 内存',
        timer_stop( 0, 3 ),
        memory_get_peak_usage() / 1024 / 1024
    );
    echo $visible ? $stat : "<!-- {$stat} -->" ;
}

$servername = "localhost";
$username = "root";
$password = "caofangkuai";
$dbname = "caofangkuai";

$resultJSON = "";
 
// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
} 
 
$sql = "SELECT json FROM resourceList";
$result = $conn->query($sql);
 
if ($result->num_rows > 0) {
    // 输出数据
    while($row = $result->fetch_assoc()) {
         $resultJSON = $resultJSON . $row["json"];
    }
} else {
    $resultJSON = "0 结果";
}
$conn->close();
?>
<html>
 <head> 
  <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" /> 
  <title>caofangkuai shop</title>
  <script src="./js/jq.js"></script>
  <link rel="stylesheet" href="./css/mui.min.css" /> 
  <link rel="stylesheet" href="./css/mdui.min.css"/>
  <link href="./css/mui.indexedlist.css" rel="stylesheet" />  
  <link rel="stylesheet" type="text/css" href="waves/waves.min.css" />
    <link rel="stylesheet" type="text/css" href="BurgerDialog/BurgerDialog.css" />
    <style>
        .btn {
            border: none;
            padding: 8px 16px;
            background-color: #EDE7F6;
            color: #673AB7;
            border-radius: 16px;
            display: inline-block;
            margin: 16px;
            transition-property: filter;
            transition-duration: .3s;
            text-transform: uppercase;
        }

        .btn:hover {
            filter: brightness(0.8);
        }

        .btn-colored {
            background-color: #673AB7;
            color: white;
            border-radius: 1024px;
        }
    </style>
 </head> 
 <body> 
 <div class="burger-dialog" id="dialog-3">
        <div class="burger-dialog-title" style="text-align: center;">caofangkuai shop</div>
        <div class="burger-dialog-content" style="text-align: center;height: 40px;overflow-y: auto;">
            欢迎来到草方块的小店
            <br>
            更新日志：<br>2025.1.15更新：<br>1.为节省服务器开支，所有资源已迁移到123云盘
        </div>
        <div class="burger-dialog-actions" style="left: 16px;">
            <button class="waves-block burger-dialog-btn-colored" onclick="closeDialog('#dialog-3');" style="width: 80%;height: 48px;font-size: 16px;">确定</button>
        </div>
    </div>
 <div id="loading">
 <p style="z-index:999;position: absolute;top:65%;right:11%;color:#070200;font-size:20px;">加载中，请耐心等待…</p>
 <iframe src="./loading.html" style="width:100%;height:100%;position: absolute;top:0px;"></iframe>
 </div>
  <div class="mui-content" style="display:none" id="main"> 
   <div id="list" class="mui-indexed-list"> 
    <div class="mui-indexed-list-search mui-input-row mui-search"> 
     <input type="search" class="mui-input-clear mui-indexed-list-search-input" placeholder="搜索资源" /> 
    </div> 
    <div class="mui-indexed-list-bar" style="display:none;"></div> 
    <div class="mui-indexed-list-alert"></div>
    <div class="mui-indexed-list-inner"> 
     <div class="mui-indexed-list-empty-alert">
      该资源不存在
     </div> 
     <ul class="mui-table-view" id="listData1"> 
      <!--列表-->
     </ul> 
    </div> 
   </div>
   <div class="mdui-fab-wrapper" id="fab"> 
<button class="mdui-fab mdui-ripple mdui-color-pink-accent"> 
<i class="mdui-icon material-icons">&#xe254;</i> 
</button> 
<div class="mdui-fab-dial"> 
<button class="mdui-fab mdui-fab-mini mdui-ripple mdui-color-pink" mdui-dialog="{target: '#dialog-1'}">
<i class="mdui-icon material-icons">&#xe145;</i>
</button> 
<button class="mdui-fab mdui-fab-mini mdui-ripple mdui-color-red" mdui-dialog="{target: '#dialog-1'}">
<i class="mdui-icon material-icons">&#xe2c3;</i> 
</button> 
<button class="mdui-fab mdui-fab-mini mdui-ripple mdui-color-orange" mdui-dialog="{target: '#dialog-1'}">
<i class="mdui-icon material-icons">&#xe872;</i> 
</button> 
</div> 
</div>
<div class="mdui-dialog" id="dialog-1">
  <div class="mdui-dialog-title">操作提示</div>
  <div class="mdui-dialog-content">请联系管理员进行 上传/更新/删除 等操作。
  <br>
  如果您是管理员请访问
  <a href="https://admin-shop.caofangkuai.top">https://admin-shop.caofangkuai.top</a>
  </div>
  <div class="mdui-dialog-actions">
    <button class="mdui-btn mdui-ripple" mdui-dialog-confirm>确定</button>
  </div>
</div>
  </div>
  <script src="./js/mdui.min.js"></script>
  <script src="./js/mui.min.js"></script> 
  <script src="./js/mui.indexedlist.js"></script>
   <script>
window.onload = function (){
mui.init();
document.getElementById("loading").style.display = "block";
document.getElementById("main").style.display = "none";
setTimeout(function() {
const data = <?php echo $resultJSON; ?>;
if(data == null || data == "" || data == undefined || data == "0 结果"){
document.body.innerHTML = "数据库加载失败";
}else{
const listData = document.getElementById("listData1");
document.getElementById("loading").style.display = "none";
document.getElementById("main").style.display = "block";
var inst = new mdui.Fab('#fab');
for (let i = 0; i < data.length; i++) { 
  const item = data[i]; 
  const name = item["name"];
  const type = item["type"];
  const smallIcon = item["smallIcon"];
  const id = item["id"];
  listData.innerHTML += '<li class="mui-table-view-cell mui-media mui-indexed-list-item"><a href="javascript:window.location.href = ' + "'" + 'download.php?id=' + id + "'" + ';"><img class="mui-media-object mui-pull-left"src="' + smallIcon + '"/><div class="mui-media-body">' + name + '<p class="mui-ellipsis">' + type + '</p></div></a></li>';
  }
   mui.ready(function() {
	var list = document.getElementById('list');
	//calc hieght
	list.style.height = document.body.offsetHeight + 'px';
	//create
	window.indexedList = new mui.IndexedList(list);
	openDialog('#dialog-3',false);
    });
}
}, 1800);
}
   </script>
   <footer>
  <p>想免费搭建一样的分站？<a href="https://github.com/csjdyr001/caofangkuai-shop">点这</a></p>
  <span id="runtimeSpan" style="color: #ff0000;"></span>
<script type="text/javascript">
    function showRuntime(){
        window.setTimeout("showRuntime()", 1000);
        var startTime = new Date("2024/7/3 22:48:00"); 
        var nowTime = new Date();
        var timestamp = (nowTime.getTime() - startTime.getTime());
        var oneDayMilliseconds = 24*60*60*1000;
        var totalDaysTmp = timestamp / oneDayMilliseconds;
        var totalDays = Math.floor(totalDaysTmp);
        var yuHoursTmp = (totalDaysTmp - totalDays) * 24;
        var yuHours = Math.floor(yuHoursTmp);
        var yuMinutesTmp = (yuHoursTmp - yuHours) * 60;
        var yuMinutes = Math.floor((yuHoursTmp - yuHours) * 60);
        var yuSeconds = Math.floor((yuMinutesTmp - yuMinutes) * 60);
        var yuHours = yuHours < 10 ? '0' + yuHours : yuHours;
        var yuMinutes = yuMinutes < 10 ? '0' + yuMinutes : yuMinutes;
        var yuSeconds = yuSeconds < 10 ? '0' + yuSeconds : yuSeconds;
        runtimeSpan.innerHTML = "本站已安全运行: " + totalDays + "天" + yuHours + "小时" + yuMinutes + "分" + yuSeconds + "秒";
    }
    showRuntime();
</script>
<style>
    #runtimeSpan{animation: change 10s infinite;font-weight: 800;}
    @keyframes change{0%{color:#AAC9CE;}25%{color:#F56A79;}50%{color:#1AA6B7;}75%{color:#FCF9F0;}100%{color:#E73B3E;}}
</style>
<br>
<?php performance(false); ?>
<br>
 ©2024 <a href="https://csjdyr001.github.io">caofangkuai</a> Corporation. All rights reserved.
</footer>
<script src="waves/waves.min.js"></script>
    <script src="BurgerDialog/BurgerDialog.js"></script>
    <script>
        var config = {
            duration: 500,
            delay: 0
        };
        Waves.init(config);
        Waves.attach('.waves-block', ['waves-block']);
        Waves.attach('.waves-circle', ['waves-circle']);
        Waves.attach('.waves-light', ['waves-light']);
        Waves.attach('.waves-classic', ['waves-classic']);
        Waves.init(config);
    </script>
 </body>
</html>