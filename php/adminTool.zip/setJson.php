<?php
echo "欢迎使用ToolBoxCN数据库终端！".PHP_EOL;
$servername = "localhost";
$username = "root";
$password = "caofangkuai";
$dbname = "caofangkuai";
echo "使用者输入：" . $_POST["code"] . "\n\n";
if($_POST["code"] == null or $_POST["code"] == "" or $_POST["code"] == "undefined"){
die("值不得为空");
}else{
$conn = mysqli_connect($servername, $username, $password);
if(! $conn )
{
    die('连接失败: ' . mysqli_error($conn) .PHP_EOL);
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
 
$sql = "UPDATE resourceList 
        SET json = '" . $_POST["code"] . "'";
 
mysqli_select_db( $conn, $dbname );
$retval = mysqli_query( $conn, $sql );
if(! $retval )
{
    die('无法更新数据: ' . mysqli_error($conn) .PHP_EOL);
}
echo PHP_EOL.'数据更新成功！' .PHP_EOL;
mysqli_close($conn);

//重新读取
$resultJSON = "";
 
// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error .PHP_EOL);
} 
 
$sql = "SELECT json FROM resourceList";
$result = $conn->query($sql);
 
if ($result->num_rows > 0) {
    // 输出数据
    while($row = $result->fetch_assoc()) {
         $resultJSON = $resultJSON . $row["json"];
    }
} else {
    $resultJSON = "0 结果";
}
echo PHP_EOL."当前结果：" . $resultJSON;
$conn->close();
}
?>