<?php
$servername = "localhost";
$username = "root";
$password = "caofangkuai";
$dbname = "caofangkuai";
if($_GET["id"] == null or $_GET["id"] == "" or $_GET["id"] == "undefined"){
die("ID不得为空");
}else{
$resultJSON1 = "";
 
// 创建连接
$conn1 = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn1->connect_error) {
    die("连接失败: " . $conn1->connect_error .PHP_EOL);
}
mysqli_query($conn1 , "set names utf8");
$sql1 = "SELECT json FROM resourceList";
$result1 = $conn1->query($sql1);
 
if ($result1->num_rows > 0) {
    // 输出数据
    while($row1 = $result1->fetch_assoc()) {
         $resultJSON1 = $resultJSON1 . $row1["json"];
    }
} else {
    die("0 结果");
}
$conn1->close();
$json = json_decode($resultJSON1);
$found = false;

foreach ($json as $item) {
    if ($item->id === $_GET["id"]) {
        // 将匹配到的对象转换为 JSON 格式并输出
        echo json_encode($item);
        $found = true;
        break; // 找到匹配项后跳出循环
    }
}

// 如果没有找到匹配项，则输出提示信息
if (!$found) {
    die("未找到匹配项");
}
}
?>