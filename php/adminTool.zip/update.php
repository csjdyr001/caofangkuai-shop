<?php
function isNull($text): bool{
if($text == null or $text == "" or $text == "undefined"){
return true;
}else{
return false;
}
}

echo "欢迎使用ToolBoxCN数据库终端！".PHP_EOL;
$servername = "localhost";
$username = "root";
$password = "caofangkuai";
$dbname = "caofangkuai";
echo "使用者输入：" . $_POST["id"] . "\n\n";
if(isNull($_POST["briefIntroduction"]) or isNull($_POST["smallIcon"]) or isNull($_POST["authorImg"]) or isNull($_POST["author"]) or isNull($_POST["downloadURL"]) or isNull($_POST["type"]) or isNull($_POST["name"]) or isNull($_POST["id"])){
die("值不得为空");
}else{
$conn = mysqli_connect($servername, $username, $password);
if(! $conn )
{
    die('连接失败: ' . mysqli_error($conn) .PHP_EOL);
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
 
$resultJSON1 = "";
 
// 创建连接
$conn1 = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn1->connect_error) {
    die("连接失败: " . $conn1->connect_error .PHP_EOL);
} 
 
$sql1 = "SELECT json FROM resourceList";
$result1 = $conn1->query($sql1);
 
if ($result1->num_rows > 0) {
    // 输出数据
    while($row1 = $result1->fetch_assoc()) {
         $resultJSON1 = $resultJSON1 . $row1["json"];
    }
} else {
    $resultJSON1 = "0 结果";
}
$conn1->close();
$array = json_decode($resultJSON1,true);
foreach ($array as $key => $value) {
    if ($value["id"] == $_POST["id"]) {
      $newObjeObject = array();
$newObjeObject["briefIntroduction"] = $_POST["briefIntroduction"];
$newObjeObject["smallIcon"] = $_POST["smallIcon"];
$newObjeObject["name"] = $_POST["name"];
$newObjeObject["type"] = $_POST["type"];
$newObjeObject["downloadURL"] = $_POST["downloadURL"];
$newObjeObject["author"] = $_POST["author"];
$newObjeObject["authorImg"] = $_POST["authorImg"];
//设置ID
$resourceId = $_POST["id"];
$newObjeObject["id"] = $resourceId;
$newArray = array($_POST["pictures1"], $_POST["pictures2"], $_POST["pictures3"], $_POST["pictures4"]);
$newObjeObject["pictures"] = $newArray;
        $array[$key] = $newObjeObject;
        break;
    }
}

$array = array_values($array);  // 重新索引数组
$resultJSON1 = json_encode($array,JSON_UNESCAPED_UNICODE);
 
$sql = "UPDATE resourceList 
        SET json = '" . $resultJSON1 . "'";
 
mysqli_select_db( $conn, $dbname );
$retval = mysqli_query( $conn, $sql );
if(! $retval )
{
    die('无法更新数据: ' . mysqli_error($conn) .PHP_EOL);
}
echo PHP_EOL.'数据更新成功！' .PHP_EOL;
mysqli_close($conn);

//重新读取
$resultJSON = "";
 
// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error .PHP_EOL);
} 
 
$sql = "SELECT json FROM resourceList";
$result = $conn->query($sql);
 
if ($result->num_rows > 0) {
    // 输出数据
    while($row = $result->fetch_assoc()) {
         $resultJSON = $resultJSON . $row["json"];
    }
} else {
    $resultJSON = "0 结果";
}
echo PHP_EOL."当前结果：" . $resultJSON;
$conn->close();
}
?>